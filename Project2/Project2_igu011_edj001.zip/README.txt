Running .ipynb file with conda 4.10.3 and python 3.6.5 

Running tensorflow 1.10.0, keras 2.2.1, CUDA 9.2, CUDNN 7.1.4


Enviroment packages and versions.
# Name                    Version                   Build  Channel
absl-py                   0.14.1                   pypi_0    pypi
argon2-cffi               21.1.0           py36h68aa20f_0    conda-forge
astor                     0.8.1                    pypi_0    pypi
attrs                     21.2.0             pyhd8ed1ab_0    conda-forge
backports                 1.0                        py_2    conda-forge
backports.functools_lru_cache 1.6.4              pyhd8ed1ab_0    conda-forge
blas                      1.0                         mkl
bleach                    4.1.0              pyhd8ed1ab_0    conda-forge
cached-property           1.5.2                    pypi_0    pypi
certifi                   2021.5.30        py36haa95532_0
cffi                      1.14.6           py36he58ceb7_1    conda-forge
colorama                  0.4.4              pyh9f0ad1d_0    conda-forge
daal4py                   2021.3.0         py36h757b272_0
dal                       2021.3.0           haa95532_564
dataclasses               0.8                      pypi_0    pypi
decorator                 5.1.0              pyhd8ed1ab_0    conda-forge
defusedxml                0.7.1              pyhd8ed1ab_0    conda-forge
entrypoints               0.3             pyhd8ed1ab_1003    conda-forge
gast                      0.5.2                    pypi_0    pypi
grpcio                    1.41.0                   pypi_0    pypi
h5py                      3.1.0                    pypi_0    pypi
icc_rt                    2019.0.0             h0cc432a_1
importlib-metadata        4.8.1            py36ha15d459_0    conda-forge
intel-openmp              2021.3.0          haa95532_3372
ipykernel                 5.3.4            py36h5ca1d4c_0
ipython                   5.8.0                    py36_1    conda-forge
ipython_genutils          0.2.0                      py_1    conda-forge
jinja2                    3.0.2              pyhd8ed1ab_0    conda-forge
joblib                    1.0.1              pyhd3eb1b0_0
jsonschema                4.1.0              pyhd8ed1ab_0    conda-forge
jupyter_client            7.0.6              pyhd8ed1ab_0    conda-forge
jupyter_core              4.8.1            py36ha15d459_0    conda-forge
keras                     2.2.1                    pypi_0    pypi
keras-applications        1.0.4                    pypi_0    pypi
keras-preprocessing       1.0.2                    pypi_0    pypi
libsodium                 1.0.18               h8d14728_1    conda-forge
m2w64-gcc-libgfortran     5.3.0                         6    conda-forge
m2w64-gcc-libs            5.3.0                         7    conda-forge
m2w64-gcc-libs-core       5.3.0                         7    conda-forge
m2w64-gmp                 6.1.0                         2    conda-forge
m2w64-libwinpthread-git   5.0.0.4634.697f757               2    conda-forge
markdown                  3.3.4                    pypi_0    pypi
markupsafe                2.0.1            py36h68aa20f_0    conda-forge
mistune                   0.8.4           py36h68aa20f_1004    conda-forge
mkl                       2020.2                      256
mkl-service               2.3.0            py36h196d8e1_0
mkl_fft                   1.3.0            py36h46781fe_0
mkl_random                1.1.1            py36h47e9c7a_0
msys2-conda-epoch         20160418                      1    conda-forge
nbconvert                 5.6.1              pyhd8ed1ab_2    conda-forge
nbformat                  5.1.3              pyhd8ed1ab_0    conda-forge
nest-asyncio              1.5.1              pyhd8ed1ab_0    conda-forge
notebook                  6.3.0            py36ha15d459_0    conda-forge
numpy                     1.19.5                   pypi_0    pypi
packaging                 21.0               pyhd8ed1ab_0    conda-forge
pandas                    1.1.5            py36hd77b12b_0
pandocfilters             1.5.0              pyhd8ed1ab_0    conda-forge
pickleshare               0.7.5                   py_1003    conda-forge
pip                       21.2.2           py36haa95532_0
plotly                    4.14.3             pyhd3eb1b0_0
prometheus_client         0.11.0             pyhd8ed1ab_0    conda-forge
prompt_toolkit            1.0.15                     py_1    conda-forge
protobuf                  3.18.1                   pypi_0    pypi
pycparser                 2.20               pyh9f0ad1d_2    conda-forge
pygments                  2.10.0             pyhd8ed1ab_0    conda-forge
pyparsing                 2.4.7              pyh9f0ad1d_0    conda-forge
pyrsistent                0.17.3           py36h68aa20f_2    conda-forge
python                    3.6.5                h0c2934d_0
python-dateutil           2.8.2              pyhd8ed1ab_0    conda-forge
python_abi                3.6                     2_cp36m    conda-forge
pytz                      2021.3             pyhd3eb1b0_0
pywin32                   301              py36h68aa20f_0    conda-forge
pywinpty                  0.5.7                    py36_0
pyyaml                    6.0                      pypi_0    pypi
pyzmq                     22.3.0           py36h1d5d788_0    conda-forge
retrying                  1.3.3                    py36_2
scikit-learn              0.24.2           py36hf11a4ad_1
scikit-learn-intelex      2021.3.0         py36haa95532_0
scipy                     1.5.2            py36h9439919_0
send2trash                1.8.0              pyhd8ed1ab_0    conda-forge
setuptools                58.2.0                   pypi_0    pypi
simplegeneric             0.8.1                      py_1    conda-forge
six                       1.16.0             pyh6c4a22f_0    conda-forge
tbb                       2021.4.0             h59b6b97_0
tensorboard               1.10.0                   pypi_0    pypi
tensorflow-gpu            1.10.0                   pypi_0    pypi
termcolor                 1.1.0                    pypi_0    pypi
terminado                 0.9.4            py36haa95532_0
testpath                  0.5.0              pyhd8ed1ab_0    conda-forge
threadpoolctl             2.2.0              pyh0d69192_0
tornado                   6.1              py36h68aa20f_1    conda-forge
traitlets                 4.3.3              pyhd8ed1ab_2    conda-forge
typing_extensions         3.10.0.2           pyha770c72_0    conda-forge
vc                        14.2                 h21ff451_1
vs2015_runtime            14.27.29016          h5e58377_2
wcwidth                   0.2.5              pyh9f0ad1d_2    conda-forge
webencodings              0.5.1                      py_1    conda-forge
werkzeug                  2.0.2                    pypi_0    pypi
wheel                     0.37.0             pyhd3eb1b0_1
wincertstore              0.2              py36h7fe50ca_0
winpty                    0.4.3                         4    conda-forge
zeromq                    4.3.4                h0e60522_1    conda-forge
zipp                      3.6.0              pyhd8ed1ab_0    conda-forge